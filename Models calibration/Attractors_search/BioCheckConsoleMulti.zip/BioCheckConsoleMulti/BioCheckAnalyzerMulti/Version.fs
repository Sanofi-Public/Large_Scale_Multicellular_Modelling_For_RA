// Copyright (c) Microsoft Research 2016
// License: MIT. See LICENSE
//
//  Module Name:
//
//      Version.fs
//
//  Abstract:
//
//      Public major.minor numbers.
//
//  Contact:
//
//      Samin Ishtiaq
//
//  Environment:
//
//
//  Notes:
//
//
module Version

let major = 1 
let minor = 0

    
